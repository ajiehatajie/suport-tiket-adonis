'use strict'

const Lucid = use('Lucid')

class Department extends Lucid {

}

module.exports = Department
